This project illustrate how to setup up a multiple package cython project.

Author: Nicolas Essis-Breton

Further reference: 
http://wiki.cython.org/PackageHierarchy

