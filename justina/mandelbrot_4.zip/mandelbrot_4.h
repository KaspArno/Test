void create_list(double min, double max, double spacing, int size, double *arr);
void mandelbrot(int iterNr, int lx, double *xcoor,int ly,double *ycoor, int m,double *steps);
